import telebot
import os
import subprocess
import signal
import random
import string
from telebot import types

# ================= CONFIG =================
API_TOKEN = "8236302983:AAGqTHPzj-56jgRg339Ci6-ElXHpqWe0lK8"
bot = telebot.TeleBot(API_TOKEN)

BASE_DIR = "running_projects"
os.makedirs(BASE_DIR, exist_ok=True)

projects = {}      # {chat_id: {project_name: {process, filename}}}
user_states = {}   # {chat_id: {"action":..., "p_name":...}}
users = {}         # {chat_id: {"name":..., "username":..., "premium":bool, "coins":int, "banned":bool}}

redeem_codes = {}  # {"CODE": coins}

ADMIN_ID = 6721648737  # Replace with your Telegram ID

BOT_STATUS = {"on": True}  
PROJECT_COIN_COST = 1   # 1 coin per project upload/run
PREMIUM_COIN_COST = 50  # Coins to unlock premium

# ================= KEYBOARDS =================
def main_keyboard(chat_id):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    if users.get(chat_id, {}).get("banned", False):
        return None
    markup.add(
        types.KeyboardButton("📢 Updates Channel"),
        types.KeyboardButton("📤 Upload File")
    )
    markup.add(
        types.KeyboardButton("📁 Check Files"),
        types.KeyboardButton("⚡ Bot Speed")
    )
    markup.add(
        types.KeyboardButton("📊 Statistics"),
        types.KeyboardButton("📞 Contact Owner")
    )
    markup.add(
        types.KeyboardButton("💎 Premium Feature"),
        types.KeyboardButton("🎫 Redeem Code")
    )
    if chat_id == ADMIN_ID:
        markup.add(types.KeyboardButton("⚙️ Admin Panel"))
    return markup

def admin_panel_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    markup.add(
        types.KeyboardButton("👤 Ban/Unban User"),
        types.KeyboardButton("🤖 Bot On/Off"),
        types.KeyboardButton("💰 Give Coins"),
        types.KeyboardButton("🎫 Redeem Code Generator"),
        types.KeyboardButton("🔙 Back")
    )
    return markup

def project_manage_keyboard(project_name):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.add(
        types.KeyboardButton(f"🆙 Update {project_name}"),
        types.KeyboardButton(f"🛑 Stop {project_name}")
    )
    return markup

def inline_button_link(text, url):
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton(text, url=url))
    return markup

# ================= START =================
@bot.message_handler(commands=['start'])
def start_handler(message):
    chat_id = message.chat.id
    user = message.from_user

    if chat_id not in users:
        users[chat_id] = {
            "name": user.first_name,
            "username": user.username,
            "premium": False,
            "coins": 0,
            "banned": False
        }

    # ইউজারের প্রোফাইল ছবি আনা
    try:
        photos = bot.get_user_profile_photos(chat_id, limit=1)
        if photos.total_count > 0:
            file_id = photos.photos[0][-1].file_id  # সর্বশেষ/সবচেয়ে বড় সাইজ
            bot.send_photo(chat_id, file_id)
    except Exception as e:
        print(f"Profile photo error: {e}")

    caption = f"""
✨ Welcome, {user.first_name}!

👤 Name: {user.first_name}
🔗 Username: @{user.username if user.username else 'N/A'}
🆔 User ID: {chat_id}
💎 Premium: {"Yes" if users[chat_id]["premium"] else "No"}
💰 Coins: {users[chat_id]["coins"]}

⚡ Each project costs {PROJECT_COIN_COST} coin to upload/run
"""
    bot.send_message(chat_id, caption, reply_markup=main_keyboard(chat_id))

# ================= MESSAGE HANDLER =================
@bot.message_handler(func=lambda m: True)
def handle_messages(message):
    chat_id = message.chat.id
    text = message.text
    state = user_states.get(chat_id)

    if users.get(chat_id, {}).get("banned", False):
        bot.send_message(chat_id,"❌ You are banned.")
        return

    # --- Inline Button Links ---
    if text == "📢 Updates Channel":
        bot.send_message(chat_id, "Click below to visit Updates Channel:",
                         reply_markup=inline_button_link("📢 Updates Channel", "https://t.me/your_channel"))
        return

    if text == "📞 Contact Owner":
        bot.send_message(chat_id, "Click below to contact the owner:",
                         reply_markup=inline_button_link("📞 Contact Owner", "https://t.me/your_username"))
        return

    # --- Other buttons ---
    if text == "⚡ Bot Speed":
        bot.send_message(chat_id, "⚡ Bot Speed: Ultra Fast 🚀")
        return

    if text == "📊 Statistics":
        total = len(projects.get(chat_id, {}))
        bot.send_message(chat_id, f"📊 Total Running Projects: {total}")
        return

    if text == "💎 Premium Feature":
        if users[chat_id]["premium"]:
            bot.send_message(chat_id, "💎 You already have premium!")
        elif users[chat_id]["coins"] >= PREMIUM_COIN_COST:
            users[chat_id]["coins"] -= PREMIUM_COIN_COST
            users[chat_id]["premium"] = True
            bot.send_message(chat_id, f"💎 Premium activated! Coins deducted: {PREMIUM_COIN_COST}")
        else:
            bot.send_message(chat_id, f"❌ Not enough coins! You need {PREMIUM_COIN_COST} coins")
        return

    if text == "📤 Upload File":
        if users[chat_id]["coins"] < PROJECT_COIN_COST and not users[chat_id]["premium"]:
            bot.send_message(chat_id,f"❌ You need at least {PROJECT_COIN_COST} coin to upload a project!")
            return
        user_states[chat_id] = {"action":"naming"}
        bot.send_message(chat_id,"📝 Enter a unique project name:")
        return

    if text == "📁 Check Files":
        if chat_id not in projects or not projects[chat_id]:
            bot.send_message(chat_id,"❌ No running projects.")
        else:
            for p in projects[chat_id]:
                bot.send_message(chat_id, f"📁 Project: {p}", reply_markup=project_manage_keyboard(p))
        return

    if text == "🎫 Redeem Code":
        user_states[chat_id] = {"action":"redeem"}
        bot.send_message(chat_id, "📝 Send your redeem code:")
        return

    # ================= ADMIN PANEL =================
    if chat_id == ADMIN_ID:
        if text == "⚙️ Admin Panel":
            bot.send_message(chat_id,"Admin Panel", reply_markup=admin_panel_keyboard())
            return
        if text == "👤 Ban/Unban User":
            user_states[chat_id] = {"action":"ban_unban"}
            bot.send_message(chat_id,"Send user ID to toggle ban/unban")
            return
        if text == "🤖 Bot On/Off":
            BOT_STATUS["on"] = not BOT_STATUS["on"]
            bot.send_message(chat_id,f"Bot is now {'ON' if BOT_STATUS['on'] else 'OFF'}")
            return
        if text == "💰 Give Coins":
            user_states[chat_id] = {"action":"give_coins_userid"}
            bot.send_message(chat_id,"📥 Send the User ID to give coins:")
            return
        if text == "🎫 Redeem Code Generator":
            code = ''.join(random.choices(string.ascii_uppercase+string.digits,k=8))
            coins = random.randint(10,100)
            redeem_codes[code] = coins
            bot.send_message(chat_id,f"🎫 Redeem Code: {code} = {coins} coins")
            return
        if text == "🔙 Back":
            bot.send_message(chat_id,"Back to main menu", reply_markup=main_keyboard(chat_id))
            return

    # --- HANDLE STATES ---
    if state:
        # Ban/unban user
        if state.get("action")=="ban_unban":
            try:
                uid = int(text)
                if uid in users:
                    users[uid]["banned"] = not users[uid]["banned"]
                    bot.send_message(chat_id,f"{uid} is now {'BANNED' if users[uid]['banned'] else 'UNBANNED'}")
                    bot.send_message(uid,f"{'❌ You are now banned' if users[uid]['banned'] else '✅ You are now unbanned'}")
                else:
                    bot.send_message(chat_id,"❌ User not found")
            except:
                bot.send_message(chat_id,"❌ Send valid numeric user ID")
            user_states[chat_id]=None
            return

        # Give coins
        if state.get("action")=="give_coins_userid":
            try:
                uid = int(text)
                if uid not in users:
                    bot.send_message(chat_id,"❌ User not found")
                    user_states[chat_id]=None
                    return
                user_states[chat_id] = {"action":"give_coins_amount","uid":uid}
                bot.send_message(chat_id,f"💰 Enter coin amount to give to user {uid}:")
            except:
                bot.send_message(chat_id,"❌ Invalid numeric user ID")
            return

        if state.get("action")=="give_coins_amount":
            try:
                coins = int(text)
                uid = state["uid"]
                users[uid]["coins"] += coins
                bot.send_message(chat_id,f"✅ Added {coins} coins to user {uid}")
                bot.send_message(uid,f"💰 You received {coins} coins from Admin!")
            except:
                bot.send_message(chat_id,"❌ Invalid coin amount")
            user_states[chat_id]=None
            return

        # Redeem code
        if state.get("action")=="redeem":
            code = text.strip().upper()
            if code in redeem_codes:
                coins = redeem_codes.pop(code)
                users[chat_id]["coins"] += coins
                bot.send_message(chat_id, f"✅ Redeemed {coins} coins!")
            else:
                bot.send_message(chat_id, "❌ Invalid redeem code!")
            user_states[chat_id] = None
            return

        # Project name
        if state.get("action")=="naming":
            p_name = text.replace(" ", "_")
            user_states[chat_id] = {"action":"uploading","p_name":p_name}
            bot.send_message(chat_id,f"📤 Send your .py file for project `{p_name}`")
            return

# ================= FILE HANDLER =================
@bot.message_handler(content_types=['document'])
def handle_document(message):
    chat_id = message.chat.id
    state = user_states.get(chat_id)
    if not state or 'p_name' not in state:
        return

    p_name = state['p_name']

    # Deduct coin
    if not users[chat_id]["premium"]:
        if users[chat_id]["coins"] < PROJECT_COIN_COST:
            bot.send_message(chat_id,"❌ You don't have enough coins!")
            user_states[chat_id] = None
            return
        users[chat_id]["coins"] -= PROJECT_COIN_COST

    # Stop existing process
    if chat_id in projects and p_name in projects[chat_id]:
        try: os.kill(projects[chat_id][p_name]['process'].pid, signal.SIGTERM)
        except: pass

    # Save & run project
    file_info=bot.get_file(message.document.file_id)
    file_data=bot.download_file(file_info.file_path)
    file_path=os.path.join(BASE_DIR,f"{chat_id}_{p_name}.py")
    with open(file_path,"wb") as f: f.write(file_data)
    process = subprocess.Popen(["python3", file_path])
    projects.setdefault(chat_id,{})[p_name] = {"process":process,"filename":file_path}

    user_states[chat_id] = None
    bot.send_message(chat_id,f"✅ Project `{p_name}` is now running! 1 coin deducted." if not users[chat_id]["premium"] else f"✅ Project `{p_name}` is now running!", reply_markup=main_keyboard(chat_id))

# ================= RUN =================
if __name__=="__main__":
    print("🤖 FULL Premium Hosting Bot running...")
    bot.infinity_polling()